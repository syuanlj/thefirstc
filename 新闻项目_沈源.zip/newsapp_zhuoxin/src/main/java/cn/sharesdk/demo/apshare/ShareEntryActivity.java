package cn.sharesdk.demo.apshare;

import cn.sharesdk.alipay.utils.AlipayHandlerActivity;

public class ShareEntryActivity extends AlipayHandlerActivity {

}
