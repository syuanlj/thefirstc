package com.syuan.myapplication.https;

/**
 * Created by sy on 2017/6/5.
 */

public class HttpUrl {
    public static final String MAIN_URL="http://118.244.212.82:9092/newsClient/";
}
